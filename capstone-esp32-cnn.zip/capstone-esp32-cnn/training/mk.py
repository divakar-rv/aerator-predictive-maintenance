import numpy as np
AX=1
X=[];y=[];cond=[];split=[];col=[]
for c in ("healthy","loose","choked"):
    a=np.array([[int(v) for v in l.split(',')] for l in open(f"data/{c}_live_01.csv") if l.strip()],float)[:,AX]/16384.0
    assert len(a)==12000
    def add(lo,hi,hop,sp):
        for s in range(lo,hi-511,hop):
            X.append(a[s:s+512]);y.append(c);cond.append(c);split.append(sp);col.append(s)
    add(0,7168,128,"train"); add(7680,9216,512,"val"); add(9728,12000,512,"test")
np.savez("windows_live.npz",X=np.array(X,np.float32),y=np.array(y),cond=np.array(cond),split=np.array(split),col=np.array(col))
import collections;print(collections.Counter(zip(y,split)))
