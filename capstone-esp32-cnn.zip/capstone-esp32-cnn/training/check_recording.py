"""Quick quality check of recordings (run on the PC, no hardware needed once files exist).

    python check_recording.py recordings/*.csv
Prints per file: effective sampling rate, timing jitter, clipping, gravity check, vibration level
(RMS in g after removing the mean, per axis) and the strongest frequency.
"""
import sys, re
import numpy as np

def load(path):
    hdr, rows = {}, []
    with open(path) as f:
        for l in f:
            l = l.strip()
            if l.startswith("#"):
                hdr.update(dict(re.findall(r"(\w+)=(\S+)", l)))
            elif l and l != "ax,ay,az":
                rows.append([int(v) for v in l.split(",")])
    return hdr, np.array(rows, dtype=np.float64)

for p in sys.argv[1:]:
    hdr, d = load(p)
    lsb = float(hdr["lsb_per_g"]); n = len(d)
    fs = (n - 1) / ((int(hdr["t_last_us"]) - int(hdr["t_first_us"])) / 1e6)
    g = d / lsb
    rms = np.sqrt(np.mean((g - g.mean(0)) ** 2, axis=0))
    ax = int(np.argmax(rms))
    sp = np.abs(np.fft.rfft((g[:, ax] - g[:, ax].mean()) * np.hanning(n)))
    f = np.fft.rfftfreq(n, 1 / fs)
    pk = f[1:][np.argmax(sp[1:])]
    print(f"{p}: n={n} fs={fs:.1f} Hz dt={hdr.get('dt_min_us')}..{hdr.get('dt_max_us')} us late={hdr.get('late')} "
          f"i2c_err={hdr.get('i2c_errors')} clipped={hdr.get('clipped')}")
    print(f"    mean(g) x={g[:,0].mean():+.3f} y={g[:,1].mean():+.3f} z={g[:,2].mean():+.3f}   "
          f"RMS(g) x={rms[0]:.4f} y={rms[1]:.4f} z={rms[2]:.4f}   strongest peak on axis {'xyz'[ax]}: {pk:.1f} Hz")
