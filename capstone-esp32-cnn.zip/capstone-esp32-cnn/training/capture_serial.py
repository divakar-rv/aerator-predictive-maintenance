"""Save recordings from mpu6050_logger.ino to CSV files on the PC.  UNTESTED on hardware.

    pip install pyserial
    python capture_serial.py COM5 healthy_s1 --n 10

COM5 = the ESP32 port (see Arduino IDE > Tools > Port; on Linux/Mac something like /dev/ttyUSB0).
Files are named <prefix>_01.csv, <prefix>_02.csv, ...   Name rule: <class>_<session>, for example
healthy_s1, unbalance_s1, healthy_s2.  Close the Arduino serial monitor first (it blocks the port).
"""
import argparse, os, sys, time
import serial

ap = argparse.ArgumentParser()
ap.add_argument("port"); ap.add_argument("prefix")
ap.add_argument("--n", type=int, default=1, help="number of 12 s recordings")
ap.add_argument("--outdir", default="recordings")
ap.add_argument("--pause", type=float, default=1.0, help="seconds between recordings")
a = ap.parse_args()
os.makedirs(a.outdir, exist_ok=True)

ser = serial.Serial(a.port, 921600, timeout=30)
time.sleep(2.0)                      # opening the port may reset the ESP32
ser.reset_input_buffer()

for k in range(1, a.n + 1):
    ser.reset_input_buffer()
    ser.write(b"r")
    lines, started = [], False
    t0 = time.time()
    while True:
        raw = ser.readline()
        if not raw:
            sys.exit("timeout: no data from the board (check port, baud rate, and that the logger sketch is loaded)")
        s = raw.decode("ascii", "replace").strip()
        if s == "START":
            started = True; continue
        if s == "END":
            break
        if started and s:
            lines.append(s)
        if time.time() - t0 > 120:
            sys.exit("timeout while receiving")
    header = [l for l in lines if l.startswith("#")]
    rows = [l for l in lines if not l.startswith("#") and l != "ax,ay,az"]
    path = os.path.join(a.outdir, f"{a.prefix}_{k:02d}.csv")
    with open(path, "w") as f:
        f.write("\n".join(header) + "\nax,ay,az\n" + "\n".join(rows) + "\n")
    print(f"saved {path}: {len(rows)} samples" + (f"   {header[0]}" if header else ""))
    time.sleep(a.pause)
