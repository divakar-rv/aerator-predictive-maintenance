2-class pump model (healthy vs fault) - trained on ONE 12 s recording per condition (y axis, +-2 g, 1 kHz)
Files: model_2class_data.h, feature_params.h, test_vectors_2class.h, results_2class.txt
Steps: open pump_live_2class.ino in Arduino IDE (all .h files stay in the same folder).
 1) set REPLAY_TEST_VECTORS to 1, upload, check the serial monitor: the replay must match tv_out.
 2) set it to 0, upload, put the sensor on the pump (same position as recording), watch healthy/fault.
Limits: split is by time inside each recording (train 0-7 s, val 7.7-9.2 s, test 9.7-12 s), NOT a held-out session.
 Test = 12 windows only. 100% here does not prove generalisation. AXIS=1 (y).
