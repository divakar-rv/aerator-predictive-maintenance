// Live healthy/fault classifier for the submersible-pump prototype (ESP32 + MPU6050, 2-class int8 CNN).
//
// Same signal chain as aerator_w512.ino (which was replay-validated on the board):
//   512 samples @ 1 kHz -> subtract mean -> Hann (symmetric) -> |DFT| bins 0..255 (not divided by N)
//   -> log1p -> (f - F_MEAN) / F_STD -> int8 -> CNN -> int8 softmax[2] -> mean over VOTE_WINDOWS windows.
//   Classes: 0 healthy, 1 fault.
//
// STATUS: NOT compiled and NOT run on a board when written. The live sampling code reads the MPU6050
// registers directly (same code as mpu6050_logger.ino); the model and feature code are the replay-validated ones.
//
// Put this file in a folder named pump_live_2class with:
//   feature_params.h, model_2class_data.h, test_vectors_2class.h   (all made by train_2class.py)
//
// REPLAY_TEST_VECTORS 1 : replay 4 stored test windows (no sensor) to check the 2-class build
// REPLAY_TEST_VECTORS 0 : live sensing. Use the SAME axis, range and filter that you used when recording.

#define REPLAY_TEST_VECTORS 1

#include <Chirale_TensorFlowLite.h>
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <Wire.h>

#include "feature_params.h"
#include "model_2class_data.h"

// ---- settings (must match the recordings the model was trained on) ----
constexpr int   N_SAMPLES    = 512;
constexpr int   N_CLASSES    = 2;
constexpr int   VOTE_WINDOWS = 5;
constexpr int   ARENA_SIZE   = 24 * 1024;
constexpr int   AXIS         = 1;       // 0 = x, 1 = y, 2 = z : the axis used by make_windows_sensor.py --axis
constexpr uint8_t RANGE_SEL  = 0;       // 0:+-2 g ... must equal RANGE_SEL in mpu6050_logger.ino
constexpr uint8_t DLPF_CFG   = 0;       // must equal DLPF_CFG in mpu6050_logger.ino
constexpr float LSB_PER_G[4] = {16384.0f, 8192.0f, 4096.0f, 2048.0f};
constexpr float SAMPLE_RATE_HZ = 1000.0f;
constexpr int   LED_PIN      = 2;       // on-board LED on most ESP32 dev boards: on while the vote says "fault"
constexpr uint8_t MPU_ADDR   = 0x68;
static const char* CLASS_NAME[N_CLASSES] = {"healthy", "FAULT"};

static_assert(N_BINS == 256, "model was trained with 256 bins");

alignas(16) static uint8_t tensor_arena[ARENA_SIZE];
static tflite::MicroMutableOpResolver<12> resolver;
static tflite::MicroInterpreter* interpreter = nullptr;
static TfLiteTensor* in_t = nullptr;
static TfLiteTensor* out_t = nullptr;
static float in_scale = 1.0f, out_scale = 1.0f;
static int in_zp = 0, out_zp = 0;

static float cos_tbl[N_SAMPLES], sin_tbl[N_SAMPLES], hann_tbl[N_SAMPLES];
static float vbuf[N_SAMPLES], feat[N_BINS], window_buf[N_SAMPLES];

static void build_tables() {
  for (int i = 0; i < N_SAMPLES; i++) {
    const double a = 2.0 * M_PI * (double)i / N_SAMPLES;
    cos_tbl[i] = (float)cos(a);
    sin_tbl[i] = (float)sin(a);
    hann_tbl[i] = (float)(0.5 - 0.5 * cos(2.0 * M_PI * (double)i / (N_SAMPLES - 1)));
  }
}

static void compute_features(const float* x, float* out) {
  float mean = 0;
  for (int n = 0; n < N_SAMPLES; n++) mean += x[n];
  mean /= N_SAMPLES;
  for (int n = 0; n < N_SAMPLES; n++) vbuf[n] = (x[n] - mean) * hann_tbl[n];
  for (int b = 0; b < N_BINS; b++) {
    const int k = FIRST_BIN + b;
    float re = 0, im = 0;
    int idx = 0;
    for (int n = 0; n < N_SAMPLES; n++) {
      re += vbuf[n] * cos_tbl[idx];
      im += vbuf[n] * sin_tbl[idx];
      idx += k;
      if (idx >= N_SAMPLES) idx -= N_SAMPLES;
    }
    out[b] = (log1pf(sqrtf(re * re + im * im)) - F_MEAN) / F_STD;
  }
}

static inline int8_t quantize(float v) {
  int q = (int)lroundf(v / in_scale) + in_zp;
  if (q > 127) q = 127;
  if (q < -128) q = -128;
  return (int8_t)q;
}

static bool run_model(const int8_t* in, int8_t* out) {
  memcpy(in_t->data.int8, in, N_BINS);
  if (interpreter->Invoke() != kTfLiteOk) return false;
  memcpy(out, out_t->data.int8, N_CLASSES);
  return true;
}

static bool init_model() {
  const tflite::Model* model = tflite::GetModel(g_model);
  if (model->version() != TFLITE_SCHEMA_VERSION) { Serial.println("Model schema mismatch"); return false; }
  resolver.AddConv2D();
  resolver.AddMaxPool2D();
  resolver.AddMean();
  resolver.AddFullyConnected();
  resolver.AddSoftmax();
  resolver.AddReshape();
  static tflite::MicroInterpreter static_interp(model, resolver, tensor_arena, ARENA_SIZE);
  interpreter = &static_interp;
  if (interpreter->AllocateTensors() != kTfLiteOk) { Serial.println("AllocateTensors failed"); return false; }
  in_t = interpreter->input(0);
  out_t = interpreter->output(0);
  in_scale = in_t->params.scale;   in_zp = in_t->params.zero_point;
  out_scale = out_t->params.scale; out_zp = out_t->params.zero_point;
  Serial.printf("Model bytes: %u | arena used: %u of %d B\n",
                (unsigned)g_model_len, (unsigned)interpreter->arena_used_bytes(), ARENA_SIZE);
  if (in_t->type != kTfLiteInt8 || out_t->type != kTfLiteInt8 ||
      (int)in_t->bytes != N_BINS || (int)out_t->bytes != N_CLASSES) {
    Serial.println("Unexpected tensor types or sizes: this is not the 256-in / 2-out int8 model.");
    return false;
  }
  return true;
}

#if REPLAY_TEST_VECTORS
#include "test_vectors_2class.h"
static void run_replay() {
  Serial.println("\n=== REPLAY of stored test windows (no sensor) ===");
  Serial.println("win truth    | python says | esp32 says | feat-diff out-diff");
  int8_t qin[N_BINS], q[N_CLASSES];
  int match = 0;
  for (int w = 0; w < TV_N; w++) {
    compute_features(tv_raw[w], feat);
    int fd = 0;
    for (int i = 0; i < N_BINS; i++) { qin[i] = quantize(feat[i]); int d = abs((int)qin[i] - (int)tv_in[w][i]); if (d > fd) fd = d; }
    if (!run_model(qin, q)) { Serial.println("Invoke failed"); return; }
    int od = 0;
    for (int i = 0; i < N_CLASSES; i++) { int d = abs((int)q[i] - (int)tv_out[w][i]); if (d > od) od = d; }
    const int cp = tv_out[w][1] > tv_out[w][0], ce = q[1] > q[0];
    if (cp == ce) match++;
    Serial.printf("%d   %-8s | %-8s | %-8s | %3d %3d\n", w, CLASS_NAME[tv_label[w]], CLASS_NAME[cp], CLASS_NAME[ce], fd, od);
  }
  Serial.printf("class matches Python: %d / %d\n", match, TV_N);
  const int R = 50;
  uint32_t t0 = micros();
  for (int r = 0; r < R; r++) compute_features(tv_raw[0], feat);
  const uint32_t tf_us = (micros() - t0) / R;
  for (int i = 0; i < N_BINS; i++) qin[i] = quantize(feat[i]);
  t0 = micros();
  for (int r = 0; r < R; r++) run_model(qin, q);
  const uint32_t tm_us = (micros() - t0) / R;
  Serial.printf("TIMING per window: features %u us | model %u us | total %u us\n", (unsigned)tf_us, (unsigned)tm_us, (unsigned)(tf_us + tm_us));
}
#else
static bool mpu_write(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool read_accel(int16_t* v) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 6) != 6) return false;
  uint8_t b[6];
  for (int i = 0; i < 6; i++) b[i] = Wire.read();
  for (int i = 0; i < 3; i++) v[i] = (int16_t)((b[2 * i] << 8) | b[2 * i + 1]);
  return true;
}
// Collects one window; returns false if it was disturbed (I2C errors, or sampling more than 2% off).
static bool read_window(float* rms_g, int* clipped) {
  const uint32_t period = (uint32_t)(1000000.0f / SAMPLE_RATE_HZ);
  uint32_t next = micros() + 2000;
  uint32_t t_first = 0, t_last = 0;
  int bad = 0, clip = 0;
  for (int n = 0; n < N_SAMPLES; n++) {
    while ((int32_t)(micros() - next) < 0) { }
    const uint32_t now = micros();
    int16_t v[3];
    if (!read_accel(v)) { bad++; v[AXIS] = 0; }
    if (v[AXIS] == 32767 || v[AXIS] == -32768) clip++;
    window_buf[n] = v[AXIS] / LSB_PER_G[RANGE_SEL];
    if (n == 0) t_first = now;
    t_last = now;
    next += period;
  }
  const float fs = (N_SAMPLES - 1) * 1e6f / (float)(t_last - t_first);
  float m = 0, s = 0;
  for (int n = 0; n < N_SAMPLES; n++) m += window_buf[n];
  m /= N_SAMPLES;
  for (int n = 0; n < N_SAMPLES; n++) s += (window_buf[n] - m) * (window_buf[n] - m);
  *rms_g = sqrtf(s / N_SAMPLES);
  *clipped = clip;
  if (bad > 0 || fabsf(fs - SAMPLE_RATE_HZ) > 0.02f * SAMPLE_RATE_HZ) {
    Serial.printf("window rejected: i2c errors %d, sample rate %.1f Hz\n", bad, fs);
    return false;
  }
  return true;
}
#endif

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("\nPump prototype: healthy/fault classifier, 2-class, 512-point");
  pinMode(LED_PIN, OUTPUT);
  build_tables();
  if (!init_model()) { while (true) delay(1000); }
#if REPLAY_TEST_VECTORS
  run_replay();
#else
  Wire.begin();
  Wire.setClock(400000);
  bool ok = mpu_write(0x6B, 0x00);
  delay(100);
  ok &= mpu_write(0x1A, DLPF_CFG);
  ok &= mpu_write(0x1C, RANGE_SEL << 3);
  if (!ok) { Serial.println("MPU6050 not responding (check wiring and address 0x68)"); while (true) delay(1000); }
  Serial.println("Live mode. Decisions every window; vote every 5 windows.");
#endif
}

void loop() {
#if REPLAY_TEST_VECTORS
  delay(1000);
#else
  static int count = 0;
  static float sum_p[N_CLASSES] = {0, 0};
  float rms; int clipped;
  if (!read_window(&rms, &clipped)) return;
  const uint32_t t0 = micros();
  compute_features(window_buf, feat);
  int8_t qin[N_BINS], q[N_CLASSES];
  for (int i = 0; i < N_BINS; i++) qin[i] = quantize(feat[i]);
  if (!run_model(qin, q)) { Serial.println("Invoke failed"); return; }
  const uint32_t dt = micros() - t0;
  float p[N_CLASSES];
  for (int i = 0; i < N_CLASSES; i++) { p[i] = (q[i] - out_zp) * out_scale; sum_p[i] += p[i]; }
  Serial.printf("window %d: %-7s P(fault)=%.2f  rms=%.4f g  clipped=%d  compute=%u ms\n",
                count + 1, CLASS_NAME[p[1] > p[0]], p[1], rms, clipped, (unsigned)(dt / 1000));
  if (++count == VOTE_WINDOWS) {
    const bool fault = sum_p[1] > sum_p[0];
    Serial.printf(">>> %d-window vote: %s (mean P(fault) %.2f)\n", VOTE_WINDOWS, CLASS_NAME[fault], sum_p[1] / VOTE_WINDOWS);
    digitalWrite(LED_PIN, fault ? HIGH : LOW);
    count = 0; sum_p[0] = sum_p[1] = 0;
  }
#endif
}
