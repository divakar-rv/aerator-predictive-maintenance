// Live vibration monitor: ESP32 + MPU6050 (Arduino IDE, board "ESP32 Dev Module").
// Reads 512 samples at 1 kHz, prints RMS per axis, the strongest frequency and a STILL / VIBRATING status
// about twice per second. Serial Monitor: 115200 baud. NOT the CNN: a live sensing check only.
// Wiring: VCC->3V3, GND->GND, SDA->GPIO21, SCL->GPIO22.  The first 6 windows set the baseline: keep it still.
#include <Wire.h>
#include <math.h>
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

static const uint8_t  MPU_ADDR = 0x68;
static const int      SDA_PIN = 21, SCL_PIN = 22, LED_PIN = 2;
static const int      N = 512;
static const float    LSB_PER_G = 16384.0f;          // +-2 g
static int16_t  s[3][N];
static float    ctab[N];
static float    base = 0;
static int      nBase = 0;

static bool writeReg(uint8_t r, uint8_t v) {
  Wire.beginTransmission(MPU_ADDR); Wire.write(r); Wire.write(v);
  return Wire.endTransmission() == 0;
}
static bool readAccel(int16_t &x, int16_t &y, int16_t &z) {
  Wire.beginTransmission(MPU_ADDR); Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 6) != 6) return false;
  uint8_t b[6];
  for (int i = 0; i < 6; i++) b[i] = Wire.read();
  x = (int16_t)((b[0] << 8) | b[1]);
  y = (int16_t)((b[2] << 8) | b[3]);
  z = (int16_t)((b[4] << 8) | b[5]);
  return true;
}

void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  delay(500);
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);
  bool ok = writeReg(0x6B, 0x00);
  delay(100);
  ok &= writeReg(0x1C, 0x00);                        // +-2 g
  for (int i = 0; i < N; i++) ctab[i] = cosf(2.0f * 3.14159265f * i / N);
  Serial.printf("\nLive vibration monitor. MPU6050 init %s. Keep the sensor still for the first 6 windows (baseline).\n", ok ? "ok" : "FAILED");
}

void loop() {
  uint32_t bad = 0;
  uint32_t next = micros() + 1000;
  for (int i = 0; i < N; i++) {
    while ((int32_t)(micros() - next) < 0) { }
    int16_t x, y, z;
    if (!readAccel(x, y, z)) { bad++; x = y = z = 0; }
    s[0][i] = x; s[1][i] = y; s[2][i] = z;
    next += 1000;
  }
  float rms[3], mean[3];
  for (int a = 0; a < 3; a++) {
    double m = 0; for (int i = 0; i < N; i++) m += s[a][i];
    m /= N; mean[a] = (float)(m / LSB_PER_G);
    double q = 0; for (int i = 0; i < N; i++) { double d = s[a][i] - m; q += d * d; }
    rms[a] = (float)(sqrt(q / N) / LSB_PER_G);
  }
  int best = 0;
  for (int a = 1; a < 3; a++) if (rms[a] > rms[best]) best = a;
  float tot = sqrtf(rms[0] * rms[0] + rms[1] * rms[1] + rms[2] * rms[2]);
  // strongest frequency (direct DFT, bins 3..255 = about 6 Hz to 498 Hz)
  float bestMag = 0; int bestK = 0;
  double m = 0; for (int i = 0; i < N; i++) m += s[best][i]; m /= N;
  for (int k = 3; k < N / 2; k++) {
    double re = 0, im = 0;
    for (int n = 0; n < N; n++) {
      int idx = (k * n) % N;
      float d = (float)(s[best][n] - m);
      re += d * ctab[idx];
      im += d * ctab[(idx + N - N / 4) % N];          // sin(t) = cos(t - 90 deg)
    }
    float mag = (float)sqrt(re * re + im * im);
    if (mag > bestMag) { bestMag = mag; bestK = k; }
  }
  float peakHz = bestK * 1000.0f / N;
  const char *state;
  if (nBase < 6) { base += tot; nBase++; if (nBase == 6) base /= 6.0f; state = "baseline"; }
  else {
    float thr = fmaxf(3.0f * base, base + 0.01f);
    bool vib = tot > thr;
    digitalWrite(LED_PIN, vib ? HIGH : LOW);
    state = vib ? "VIBRATING" : "still";
  }
  Serial.printf("RMS g x=%.4f y=%.4f z=%.4f | total %.4f | peak %.0f Hz (axis %c) | %s%s\n",
                rms[0], rms[1], rms[2], tot, peakHz, "xyz"[best], state, bad ? "  (I2C errors!)" : "");
}
