// MPU6050 vibration logger for ESP32 (Arduino IDE, board: "ESP32 Dev Module").
// UNTESTED on hardware when written. Records 12 s at 1 kHz on three axes into RAM, then
// sends it over USB serial as CSV. Use capture_serial.py on the PC to save the files.
//
// Wiring: MPU6050 VCC -> 3V3, GND -> GND, SDA -> GPIO21, SCL -> GPIO22, AD0 -> GND (address 0x68).
// Serial monitor / script: 921600 baud. Send the character 'r' to start one recording.
#include <Wire.h>
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

static const uint8_t  MPU_ADDR   = 0x68;
static const int      SDA_PIN    = 21;
static const int      SCL_PIN    = 22;
static const uint32_t FS_HZ      = 1000;      // sampling rate (the model expects 1 kHz)
static const uint32_t SECONDS    = 12;        // same length as one column of the dataset
static const uint32_t N          = FS_HZ * SECONDS;
static const uint8_t  RANGE_SEL  = 0;         // 0:+-2 g, 1:+-4 g, 2:+-8 g, 3:+-16 g (raise if clipping is reported)
static const uint8_t  DLPF_CFG   = 0;         // 0 = widest accelerometer bandwidth (260 Hz); see the procedure

static const float LSB_PER_G[4] = {16384.0f, 8192.0f, 4096.0f, 2048.0f};
static const uint8_t RANGE_G[4] = {2, 4, 8, 16};

int16_t *buf = nullptr;                       // N x 3 samples (72 KB)

static bool writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}

static bool readAccel(int16_t &x, int16_t &y, int16_t &z) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);                           // ACCEL_XOUT_H
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 6) != 6) return false;
  uint8_t b[6];
  for (int i = 0; i < 6; i++) b[i] = Wire.read();     // read in order (C++ does not fix the order inside one expression)
  x = (int16_t)((b[0] << 8) | b[1]);
  y = (int16_t)((b[2] << 8) | b[3]);
  z = (int16_t)((b[4] << 8) | b[5]);
  return true;
}

static uint8_t whoAmI() {
  Wire.beginTransmission(MPU_ADDR); Wire.write(0x75);
  Wire.endTransmission(false);
  Wire.requestFrom((int)MPU_ADDR, 1);
  return Wire.available() ? Wire.read() : 0xFF;
}

static bool sensorInit() {
  bool ok = writeReg(0x6B, 0x00);             // wake up, internal oscillator
  delay(100);
  ok &= writeReg(0x1A, DLPF_CFG);             // CONFIG: digital low-pass filter
  ok &= writeReg(0x1C, RANGE_SEL << 3);       // ACCEL_CONFIG: full-scale range
  return ok;
}

void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);   // brownout detector OFF (pump test only)
  Serial.begin(921600);
  delay(500);
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);
  buf = (int16_t *)malloc(sizeof(int16_t) * 3 * N);
  Serial.println();
  if (!buf) { Serial.println("ERROR: not enough memory for the buffer"); while (1) delay(1000); }
  bool ok = sensorInit();
  Serial.printf("# MPU6050 logger ready. init %s, WHO_AM_I=0x%02X (0x68 expected; clones may differ)\n",
                ok ? "ok" : "FAILED", whoAmI());
  Serial.println("# Send 'r' to record.");
}

static void recordAndSend() {
  uint32_t late = 0, dtMin = 0xFFFFFFFF, dtMax = 0, bad = 0, clip = 0;
  uint32_t tFirst = 0, tLast = 0, prev = 0;
  uint32_t next = micros() + 2000;            // first sample 2 ms from now
  const uint32_t period = 1000000UL / FS_HZ;
  for (uint32_t i = 0; i < N; i++) {
    while ((int32_t)(micros() - next) < 0) { }          // wait for the sample instant
    uint32_t now = micros();
    if ((int32_t)(now - next) > 200) late++;            // more than 200 us behind schedule
    int16_t x, y, z;
    if (!readAccel(x, y, z)) { bad++; x = y = z = 0; }
    buf[3 * i] = x; buf[3 * i + 1] = y; buf[3 * i + 2] = z;
    if (x == 32767 || x == -32768 || y == 32767 || y == -32768 || z == 32767 || z == -32768) clip++;
    if (i == 0) tFirst = now; else { uint32_t dt = now - prev; if (dt < dtMin) dtMin = dt; if (dt > dtMax) dtMax = dt; }
    prev = now; tLast = now;
    next += period;
  }
  Serial.println("START");
  Serial.printf("# n=%lu fs_nominal=%lu range_g=%u lsb_per_g=%.0f dlpf=%u t_first_us=%lu t_last_us=%lu "
                "dt_min_us=%lu dt_max_us=%lu late=%lu i2c_errors=%lu clipped=%lu\n",
                (unsigned long)N, (unsigned long)FS_HZ, RANGE_G[RANGE_SEL], LSB_PER_G[RANGE_SEL], DLPF_CFG,
                (unsigned long)tFirst, (unsigned long)tLast, (unsigned long)dtMin, (unsigned long)dtMax,
                (unsigned long)late, (unsigned long)bad, (unsigned long)clip);
  Serial.println("ax,ay,az");
  char line[40];
  for (uint32_t i = 0; i < N; i++) {
    int n = snprintf(line, sizeof(line), "%d,%d,%d\n", buf[3 * i], buf[3 * i + 1], buf[3 * i + 2]);
    Serial.write((const uint8_t *)line, n);
  }
  Serial.println("END");
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'r' || c == 'R') recordAndSend();
  }
}
