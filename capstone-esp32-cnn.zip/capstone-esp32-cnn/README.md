# Vibration-based fault classification of aerator motors using an edge-deployed CNN on ESP32

Capstone project, VIT Chennai (B.Tech ECE). Authors: Divakar V., Lingeshvar R., U. Pherarasan. Guide: Dr. Arivarasi A.

This folder holds the draft paper, the ESP32 firmware, the training scripts and the pump recordings.

## Status (what is and is not shown)

| Item | Status |
|---|---|
| 4-class int8 CNN (healthy / unbalance / misalignment / coupling) trained on a public motor-pump dataset | Done. Test accuracy 77.7 % (3-run mean 74.8 %), 86.8 % with 5-window averaging |
| ESP32 deployment of the 4-class model | Verified by **replay of 8 stored dataset windows** (8/8 class matches, 22.5 ms per window, model 7,112 B). Not tested on live sensor data |
| MPU6050-class sensor on the ESP32 | Bench-checked: 1 kHz, noise floor 0.005-0.007 g RMS per axis |
| 2-class (healthy / fault) model on a 3-6 V submersible pump | Trained on one 12 s recording per condition (healthy, loose, choked), time split inside each recording. 100 % on 12 held-out windows is a **feasibility result only** (overfitting, no held-out session) |
| Live classification on the ESP32 with the 2-class model | **Not verified.** The sketch is provided, but no authentic serial log is included |
| Test on an actual aerator motor | Not done |

## Layout
- `paper/` - draft conference paper (`paper.tex`, `paper.pdf`)
- `firmware/pump_live_2class/` - ESP32 sketch and model headers (set `REPLAY_TEST_VECTORS` 1 for the replay check, 0 for live; `AXIS = 1`). Not yet compiled on a real Arduino setup by the author of the sketch
- `firmware/live_monitor/` - live RMS / strongest-frequency monitor (no neural network)
- `firmware/mpu6050_logger/` - 12 s, 1 kHz recorder
- `training/` - `capture_serial.py`, `check_recording.py`, `mk.py` (builds windows), `train_2class.py`, results
- `data/` - the three pump recordings (ax, ay, az raw counts at +-2 g, 1 kHz)

## Reproduce the 2-class model
```
python training/mk.py          # run from this folder; writes windows_live.npz
python training/train_2class.py windows_live.npz
```
Requires Python 3, NumPy, scikit-learn and TensorFlow.

## Limits
One small pump, one sensor, one recording per condition. Do not read the 100 % score as generalisation. The 4-class model was trained on public data, and simulations show it is sensitive to sensor scale, bandwidth and noise, so it needs retraining on the real sensor.
